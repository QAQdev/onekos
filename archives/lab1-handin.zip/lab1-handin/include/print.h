#ifndef _PRINT_H
#define _PRINT_H

#include "types.h"

void puts(char *s);
void puti(uint64 x); // prevent overflow!

#endif
