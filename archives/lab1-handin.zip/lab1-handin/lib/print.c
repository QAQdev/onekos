#include "print.h"
#include "sbi.h"

void puts(char *s) {

    while (*s != '\0'){
        sbi_ecall(SBI_PUTCHAR, 0x0, *s, 0, 0, 0, 0, 0);
        ++s;
    }
    return;
}

void puti_entry(uint64 x){

    if (x == 0) return;
    puti_entry(x/10);
    sbi_ecall(SBI_PUTCHAR, 0x0, x%10+'0', 0, 0, 0, 0, 0);
}

void puti(uint64 x) {

    // negatives and zero are processed independent from positives 
    if (x < 0) {
        sbi_ecall(SBI_PUTCHAR, 0x0, '-', 0, 0, 0, 0, 0);
        x = -x;
    }
    else if (x == 0){
        sbi_ecall(SBI_PUTCHAR, 0x0, '0', 0, 0, 0, 0, 0);
    }

    puti_entry(x);
}
